package FactoryDemo;

public class FactoryTest {  
	  
    public static void main(String[] args) {  
        SendFactory sendFactory = new SendFactory();  
        Sender sender = sendFactory.produce("sms");  
        sender.Send();  
        
        SendFactory2 factory = new SendFactory2();  
        Sender sender2 = factory.produceMail();  
        sender2.Send();  
        
        Sender sender3 = SendFactory3.produceMail();  
        sender3.Send();
    }  
}  
