package FactoryDemo;

public class MailSender implements Sender{  
	  
    @Override  
    public void Send() {  
        // TODO Auto-generated method stub  
        System.out.println("this is MailSender");  
    }  
  
} 