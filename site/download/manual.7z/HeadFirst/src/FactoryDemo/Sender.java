package FactoryDemo;

public interface Sender {  
	  
    public abstract void Send();  
}  