package Singleton;



public class MainClass {

	public static void main(String[] args) {
		
//		Singleton single1 = new Singleton();
		Singleton single = Singleton.getInstance();
//		single.instance;
//		Singleton single2 = Singleton.getInstance();
//		if(single == single2){
//			System.out.print("==========single��single2��ͬһʵ��============");
//		}else{
//			System.out.print("==========single��single2�ǲ�ͬʵ��============");
//		}
		single.showMessage();
		
		SingletonHungry singlehungry = SingletonHungry.getInstance();
		
		SingletonStatic singlestatic = SingletonStatic.getInstance();
		
		
	}

}
