(function() {

    return function(request, script) {
		//引入假数据，实际开发不可以引入
		require('$svr/mock_api.js');
		
		//打印前端传过来的查询条件
		log(request);
		
		var sql = 'select clttime,cityname,webrspsuccrate,webdownloadrate,webrspdelay ' +
			'from aggr_web_day_month_201607 ' +
			'where clttime between "' + request.beginTime + '" and "' + request.endTime +
			'" and city in (' + request.citys.join(',') + ')';
			
		var tableUtil = require('app/common/server/util/tableUtil.js');
		sql = tableUtil.generatePagingSQL(sql, request.paging.pageSize, request.paging.currentPage || 1);
		
		var data = matrix(sql);
		data.header = ['日期', '城市名','网页响应成功率','网页下载速率','网页响应时延'];
		return data;
    }

})();
