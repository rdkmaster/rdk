define('main', ['application', 'utils', 'i18n', 'blockUI',
	'rd.controls.Time', 'rd.controls.ComboSelect', 'rd.controls.BasicSelector'],
function(application, utils, i18n) {
// 创建一个RDK的应用
var app = angular.module("rdk_app", ['rd.core', 'blockUI',
	'rd.controls.Time', 'rd.controls.ComboSelect', 'rd.controls.BasicSelector']);

app.config(['blockUIConfig', function(blockUIConfig) {
    // blockUI默认只要有ajax请求在进行，就会自动启动，阻止页面响应鼠标事件
    // 使用下面代码可以阻止自动模式，启用手动模式
    // blockUIConfig.autoBlock=false
    // 然后在需要阻止页面相应鼠标事件的时候，使用下面代码
    // blockUI.start();
    // 在需要继续相应页面相应鼠标事件的时候，使用下面代码
    // blockUI.stop();

    // blockUI的详细用法参考 https://github.com/McNull/angular-block-ui
    blockUIConfig.template = '<div class="block-ui-message-container">\
                                  <img src="images/loding.gif" />\
                              </div>';
}]);

// 创建一个控制器
app.controller('rdk_ctrl', ['$scope', 'DataSourceService', 'blockUI',
function(scope, DSService, blockUI) {
i18n.$init(scope);
application.initDataSourceService(DSService);
/************************ 应用的代码逻辑开始 ************************/

	scope.timeSetting  = {
		value: ['now-2h', 'now'],
		selectGranularity: true,
		granularity: "hour",
		granularityItems: [{
			label: "15分钟",
			value: "quarter"
		}, {
			label: "小时",
			value: "hour"
		}, {
			label: "天",
			value: "date"
		}, {
			label: "月",
			value: "month"
		}]
	}
	
	scope.citys = [
		{id: 1, name: '南京'},
		{id: 2, name: '扬州'},
		{id: 3, name: '苏州'},
		{id: 4, name: '镇江'},
	]

	scope.selected2string = function(selected, context, index) {
		var selectedCitys = '';
		angular.forEach(selected, function(city) {
			selectedCitys += city.name + ' ';
		});
		return selectedCitys;
	}

/************************ 应用的代码逻辑结束 ************************/
}]);

/********************************************************************
          应用如果将代码写在此处，可能会导致双向绑定失效
                需要手工调用 scope.$apply() 函数
          若非有特别的需要，否则请不要将代码放在这个区域
 ********************************************************************/

});

/********************************************************************
                       这个区域不要添加任何代码
 ********************************************************************/
