define('main', ['application', 'utils', 'i18n', 'blockUI',
	'rd.controls.Time', 'rd.controls.ComboSelect', 'rd.controls.BasicSelector',
	'rd.controls.Table', 'rd.controls.Graph'],
function(application, utils, i18n) {
// 创建一个RDK的应用
var app = angular.module("rdk_app", ['rd.core', 'blockUI',
	'rd.controls.Time', 'rd.controls.ComboSelect', 'rd.controls.BasicSelector',
	'rd.controls.Table', 'rd.controls.Graph']);

app.config(['blockUIConfig', function(blockUIConfig) {
    // blockUI默认只要有ajax请求在进行，就会自动启动，阻止页面响应鼠标事件
    // 使用下面代码可以阻止自动模式，启用手动模式
    // blockUIConfig.autoBlock=false
    // 然后在需要阻止页面相应鼠标事件的时候，使用下面代码
    // blockUI.start();
    // 在需要继续相应页面相应鼠标事件的时候，使用下面代码
    // blockUI.stop();

    // blockUI的详细用法参考 https://github.com/McNull/angular-block-ui
    blockUIConfig.template = '<div class="block-ui-message-container">\
                                  <img src="images/loding.gif" />\
                              </div>';
}]);

// 创建一个控制器
app.controller('rdk_ctrl', ['$scope', 'DataSourceService', 'blockUI', 'EventService',
function(scope, DSService, blockUI, EventService) {
i18n.$init(scope);
application.initDataSourceService(DSService);
/************************ 应用的代码逻辑开始 ************************/

	scope.showResult = false;
	EventService.register('myGraph', 'click', function(event, item) {
		alert(item.seriesName + ' = ' + item.value);
	});

	scope.timeSetting  = {
		value: ['now-2h', 'now'],
		selectGranularity: true,
		granularity: "hour",
		granularityItems: [{
			label: "15分钟",
			value: "quarter"
		}, {
			label: "小时",
			value: "hour"
		}, {
			label: "天",
			value: "date"
		}, {
			label: "月",
			value: "month"
		}]
	}

	scope.selected2string = function(selected, context, index) {
		var selectedCitys = '';
		angular.forEach(selected, function(city) {
			selectedCitys += city.name + ' ';
		});
		return selectedCitys;
	}
	
	scope.cityProcessor = function(rawCitys) {
		var citys = [];
		angular.forEach(rawCitys.data, function(item) {
			citys.push({id: item[0], name: item[1]});
		});
		//必须把转换后的数据返回
		return citys;
	}
	
	scope.search = function() {
		//由于服务端需要的是选中城市id列表，因此需要先处理一下选中的城市
		var citys = [];
		angular.forEach(scope.selectedCitys, function(city) {
			citys.push(city.id);
		});
		
		var condition = {
			beginTime: scope.timeSetting.value[0],
			endTime: scope.timeSetting.value[1],
			citys: citys,
			paging: {
				//一页的记录数
				pageSize:20
			}
		}
		console.log(condition);
		
		
		//数据源dsWebAnalysis是在页面中定义了的，这里直接取用即可
		var ds = DSService.get('dsWebAnalysis');
		ds.query(condition);
		
		scope.showResult = true;
	}

	scope.setting = {
		"columnDefs": [
			{
				title : "详情",
				render : '<a ng-click="appScope.click(item)" href="javascript:void(0)">查看</a>'
			}
		]
	}
	
	scope.click = function(item) {
		console.log(item);
		var txt = '日期：' + item.clttime + '\n' +
				'城市名：' + item.cityname + '\n' +
				'网页响应成功率：' + item.webrspsuccrate + '\n' +
				'网页下载速率：' + item.webdownloadrate + '\n' +
				'网页响应时延：' + item.webrspdelay;
		alert(txt);
	}

/************************ 应用的代码逻辑结束 ************************/
}]);

/********************************************************************
          应用如果将代码写在此处，可能会导致双向绑定失效
                需要手工调用 scope.$apply() 函数
          若非有特别的需要，否则请不要将代码放在这个区域
 ********************************************************************/

});

/********************************************************************
                       这个区域不要添加任何代码
 ********************************************************************/
