(function() {
    return {
        "en_US": {
            clttime: 'Time',
            cityname: 'City',
            webrspsuccrate: 'Web Response Success Rate(%)',
            webdownloadrate: 'Web Download Rate(bps)',
            webrspdelay: 'Web Response Delay(ms)'
        },
        "zh_CN": {
            clttime: '时间',
            cityname: '城市',
            webrspsuccrate: '网页响应成功率(%)',
            webdownloadrate: '网页下载速率(bps)',
            webrspdelay: '网页响应时延(ms)'
        }
    }
})();