define(['rd.modules.i18n', 'rest!/rdk/service/app/common/locale'],
function(i18n, locale) {
 
    //默认语言环境，在获取语言服务失败时使用
    var defaultLocale = window.navigator.language;

    return i18n.init(


    //======================= 开始 =======================
    //将前端的国际化词条写在下面的json对象中
    //开始和结束标记以外的区域，请不要改动


    {
    "en_US": {
        query: "Query",
        detail: "Detail",
        view: "View",
        city: "City",
        time: "Time",
        gr_quater: "15Min",
        gr_hour: "Hour",
        gr_date: "Date",
        gr_month: "Month",
        webanalyse: "Web Analyse",
        dummy: "Dummy Data",
        rspsucc: "Web Response Success Rate",
        webdlrate: "Web Download Rate",
    },
    "zh_CN": {
        query: "查询",
        detail: "详情",
        view: "查看",
        city: "地市",
        time: "时间",
        gr_quater: "15分钟",
        gr_hour: "小时",
        gr_date: "天",
        gr_month: "月",
        webanalyse: "网页分析",
        dummy: "纯属虚构",
        rspsucc: "网页响应成功率",
        webdlrate: "网页下载速率",
    }
}


    //======================= 结束 =======================






    , (function fixLocale(rawLocale) {
            var locale;
            try {
                locale = eval('(' + rawLocale + ')').result;
            } catch (e) {
            }
            if (locale != 'en_US' && locale != 'zh_CN' && locale != 'zh-CN' && locale != 'en-US') {
                console.warn('invalid locale data: [' + rawLocale + '], using ' + defaultLocale);
                locale = defaultLocale;
            }
            return locale.replace('-', '_');
        })(locale)
    );
});