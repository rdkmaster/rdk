(function() {

    return function(request, script) {
        //服务的第一行代码写在这里！
        require('$svr/mock_api.js');

        log('querying citys!');
        var m = Data.fetch('select cityid, cityname from dim_comm_city');
        log('city result', m);
        return m;
    }

})();
