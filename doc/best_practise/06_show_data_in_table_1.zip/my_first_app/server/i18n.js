﻿(function() {
    return {
        "en_US": {
            greetings: 'Greetings from {0}!',
        },
        "zh_CN": {
            greetings: '这是来自 {0} 服务的问候！',
        }
    }
})();