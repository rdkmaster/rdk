({
    baseUrl:"libs/rdk/",
    name: "rdk",
    out: "main.min.js",
    mainConfigFile : "./libs/rdk/mainconfig.js"	,
    findNestedDependencies : true,
    separateCSS: true,
})